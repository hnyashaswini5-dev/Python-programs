print('-'*90)
print("WELCOME TO PIZZA HUT!!!!!\nHAVE A NICE DAY!!!")
print('-'*90)
items={1:['Veg Margharita',300],2:['American Cheese corn',400],3:['chicken loaded',500],
       4:['Panneer mix Margharita',250],5:['chicken tikka cheese ',560]}
print("These are the Items Available:")
choice=int(input('''
                 1.Veg Margharita
                 2.American Cheese corn
                 3.chicken loaded
                 4.Panneer mix Margharita
                 5.chicken tikka cheese
                 Enter Your Choice:'''))
if 1<=choice<=5:
    print(f'You have selected {items[choice][0]} and price for one {items[choice][0]} is {items[choice][1]}')
    total_bill=0
    q=int(input("Enter the Quntity:"))
    if q==0:
        q=1
    total_bill+=items[choice][1]*q
    print(f"The Total Bill As of Now is {total_bill}") 
    t=int(input("Do you need to add more items?\nEnter1.Yes\n0.No:"))
    if t==1:
        choice=int(input('''
                     1.Veg Margharita
                     2.American Cheese corn
                     3.chicken loaded
                     4.Panneer mix Margharita
                     5.chicken tikka cheese
                     Enter Your Choice:'''))
        if 1<=choice<=5:
            print(f'You have selected {items[choice][0]} and price for one {items[choice][0]} is {items[choice][1]}')

            q=int(input("Enter the Quntity:"))
            if q==0:
                q=1
            total_bill+=items[choice][1]*q
            print(f"The Total Bill As of Now is {total_bill}")
        else:
            print("Invalid Choice")
    addon={1:['Dips',20],2:['Coke',90],3:['French Fries',120],4:['Burger',200]}
    print("These are the Add-ons Available")
    ch=int(input('''
                 1.Dips
                 2.Coke
                 3.French Fries
                 4.Burger
                 Enter Your Choice:'''))
    if 1<=ch<=4:

        print(f"You have selected {addon[ch][0]} and price of one {addon[ch][0]} is {addon[ch][1]}")
        q=int(input("Enter the Quantity:"))
        if q==0:
            q=1
        total_bill+=addon[ch][1]*q
        print(f"The Total Bill As of Now is {total_bill}")
        t=int(input("Do you need to add more Addons?\nEnter1.Yes\n0.No:"))
    else:
        print("Invalid Choice")
    if t==1:
        ch=int(input('''
                 1.Dips
                 2.Coke
                 3.French Fries
                 4.Burger
                 Enter Your Choice:'''))
        
        if 1<=ch<=4:
            print(f"You have selected {addon[ch][0]} and price of one {addon[ch][0]} is {addon[ch][1]}")
            q=int(input("Enter the Quantity:"))
            if q==0:
                q=1
            total_bill+=addon[ch][1]*q
            print(f"The Total Bill As of Now is {total_bill}")
        else:
            print("Invalid Choice")
    print('-'*90)
    print("Thank You for Your Time")
    print(f"The Total Bill As of Now is {total_bill}")
    print('-'*90)
    payment=int(input("Enter the Mode of Payment1.Cash\n2.UPI\n3.CARD:"))
    print('-'*90)
    print("Recieved the Payment Successfully")
    print("Wait at the Count Counter for 10 Minutes")
    print("Thank You\nPlease Visit Again")
    print('-'*90)
else:
    print("Invalid Choice")
    
